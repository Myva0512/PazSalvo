﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PazYSalvoAPP.Business.Services;
using PazYSalvoAPP.Models;
using PazYSalvoAPP.WebApp.Models.ViewModels;
using System.Globalization;


namespace PazYSalvoAPP.WebApp.Controllers.Clientes
{
    public class ClienteController : Controller
    {
        private readonly IClienteService _clienteService;
        public ClienteController(IClienteService clienteService)
        {
            _clienteService = clienteService;
        }
        public IActionResult Index()
        {

            List<Persona> personas = _clienteService.ObtenerPersona();

            // Pasar los datos a la vista
            ViewBag.Personas = personas;

            // servicios
            List<Role> roles = _clienteService.ObtenerRol();

            // Pasar los datos a la vista
            ViewBag.Roles = roles;
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> ListarCliente()
        {
            IQueryable<Cliente>? consultaDeClientes = await _clienteService.LeerTodos();

            List<Cliente> listadoDeClientes = consultaDeClientes.Select(f => new Cliente
            {
                Id = f.Id,
                PersonaId = f.PersonaId,
                RolId = f.RolId,
                
                
               

        }).ToList();

            return PartialView("_ListadoDeClientes",
                              listadoDeClientes);
        }

        [HttpPost]
        public async Task<IActionResult> AgregarCliente([FromBody] ClienteViewModel model)
        {
            Cliente cliente = new Cliente()
            {
                Id = model.Id,
                PersonaId = model.PersonaId,
                RolId = model.RolId,
                
                
            };

            bool response = await _clienteService.Insertar(cliente);

            if (response)
            {

                return Json(new { success = true, message = "Cliente agregado con éxito" });
            }
            else
            {
                return Json(new { success = false, message = "Error al agregar al cliente" });
            }

        }

        public async Task<IActionResult> EditarClientes(int id)
        {
            var cliente = await _clienteService.Leer(id);
            ClienteViewModel clienteAEditar = new ClienteViewModel()
            {
                Id = cliente.Id,
                PersonaId = cliente.PersonaId,
                RolId = cliente.RolId,
              
             
            };

            List<Persona> personas = _clienteService.ObtenerPersona();

            ViewBag.Personas = personas;

            // servicios
            List<Role> roles = _clienteService.ObtenerRol();

            // Pasar los datos a la vista
            ViewBag.Roles = roles;



            return View("EditarClientes", clienteAEditar);
        }

        [HttpPost]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> ActualizarCliente(ClienteViewModel model)
        {
            Cliente clienteAEditar = await _clienteService.Leer(model.Id);
            if (clienteAEditar == null)
            {
                TempData["ErrorMessage"] = "Cliente no encontrado";
                return RedirectToAction("EditarClientes", new { id = model.Id });
            }

            Cliente cliente = new Cliente()
            {
                Id = model.Id,
                PersonaId = model.PersonaId,
                RolId = model.RolId,
                Persona= model.Persona,
                Rol = model.Rol,
              
            };

            bool response = await _clienteService.Actualizar(cliente);

            if (response)
            {
                return RedirectToAction("Index", "Cliente");
            }
            else
            {
                TempData["ErrorMessage"] = "Error al actualizar Cliente";
                return RedirectToAction("EditarClientes", new { id = model.Id });
            }

         

        }
    }
}
