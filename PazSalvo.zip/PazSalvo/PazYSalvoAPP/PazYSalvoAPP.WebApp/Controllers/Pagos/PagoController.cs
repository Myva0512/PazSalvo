﻿using Microsoft.AspNetCore.Mvc;
using PazYSalvoAPP.Business.Services;
using PazYSalvoAPP.Models;
using PazYSalvoAPP.WebApp.Models.ViewModels;
using System.Globalization;

namespace PazYSalvoAPP.WebApp.Controllers.Pagos
{
    public class PagoController : Controller
    {
        private readonly IPagosService _PagoService;
        public PagoController(IPagosService PagoService)
        {
            _PagoService = PagoService;
        }
        public IActionResult Index()


        {

            List<Factura> factura = _PagoService.ObtenerFacturas();
            ViewBag.factura = factura;

            return View();
        }


    
        [HttpGet]
        public async Task<IActionResult> ListarPagos()
        {
            IQueryable<Pago>? consultaDePagos = await _PagoService.LeerTodos();

            List<Pago> listadoDePagos = consultaDePagos.Select(f => new Pago
            {
                Id = f.Id,
                MontoDePago= f.MontoDePago,
                FacturaId = f.FacturaId,
                Activo = f.Activo

            }).ToList();

            return PartialView("_ListadoDePagos",
                              listadoDePagos);
        }

        [HttpPost]
        public async Task<IActionResult> AgregarPagos([FromBody] PagoViewModel model)
        {
            Pago pago = new Pago()
            {
                Id = model.Id,
                MontoDePago = model.MontoDePago,
                FacturaId = model.FacturaId,
                Activo = model.Activo

            };

            bool response = await _PagoService.Insertar(pago);

            if (response)
            {

                return Json(new { success = true, message = "Pago ingresado con éxito" });
            }
            else
            {
                return Json(new { success = false, message = "Error! no se ha podido ingresar el pago" });
            }

        }

        public async Task<IActionResult> EditarPago(int id)
        {
            var pago = await _PagoService.Leer(id);
            PagoViewModel PagoAEditar = new PagoViewModel()
            {
                Id = pago.Id,
                MontoDePago = pago.MontoDePago,
                FacturaId = pago.FacturaId,
                Activo = pago.Activo
            };


            return View("EditarPago", PagoAEditar);
        }

        [HttpPost]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> ActualizarPago(PagoViewModel model)
        {
            Pago pagoAEditar = await _PagoService.Leer(model.Id);
            if (pagoAEditar == null)
            {
                TempData["ErrorMessage"] = "Pago no encontrada";
                return RedirectToAction("EditarPagos", new { id = model.Id });
            }

            Pago pago = new Pago()
            {
                Id = model.Id,
                MontoDePago = model.MontoDePago == null ? pagoAEditar.MontoDePago : model.MontoDePago,
                FacturaId = model.FacturaId == null ? pagoAEditar.FacturaId : model.FacturaId,
                Activo = model.Activo == null ? pagoAEditar.Activo : model.Activo

            };

            bool response = await _PagoService.Actualizar(pago);

            if (response)
            {
                return RedirectToAction("Index", "Pago");
            }
            else
            {
                TempData["ErrorMessage"] = "Error al actualizar el pago";
                return RedirectToAction("EditarPago", new { id = model.Id });
            }
        }
    }
}
