﻿using Microsoft.AspNetCore.Mvc;
using PazYSalvoAPP.Business.Services;
using PazYSalvoAPP.Models;
using PazYSalvoAPP.WebApp.Models.ViewModels;

namespace PazYSalvoAPP.WebApp.Controllers.MediosDePagos
{


    public class MedioDePagoController : Controller
    {
        private readonly IMedioDePagoService _MedioDePagoService;
        public MedioDePagoController(IMedioDePagoService mediodepagoservice)
        {
            _MedioDePagoService = mediodepagoservice;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> ListarMediosDePago()
        {
            IQueryable<MediosDePago>? consultaDeMedioDePago = await _MedioDePagoService.LeerTodos();

            List<MediosDePago> listadoDeMediosdePago = consultaDeMedioDePago.Select(m => new MediosDePago
            {
                Id = m.Id,
                Nombre = m.Nombre,
                Descripcion = m.Descripcion,
               
               

            }).ToList();

            return PartialView("_ListadoDeMedioDePago",
                              listadoDeMediosdePago);
        }

        [HttpPost]
        public async Task<IActionResult> AgregarMediosDePago([FromBody] MedioDePagoViewModel model)
        {
            MediosDePago medioDePago = new MediosDePago()
            {
                Id = model.Id,
                Nombre = model.Nombre,
                Descripcion = model.Descripcion,
                
              
            };

            bool response = await _MedioDePagoService.Insertar(medioDePago);

            if (response)
            {

                return Json(new { success = true, message = "Medio de pago agregado con exito!" });
            }
            else
            {
                return Json(new { success = false, message = "Error! al agregar el medio de pago" });
            }

        }

        public async Task<IActionResult> EditarMedioDePago(int id)
        {
            var mediosDePago = await _MedioDePagoService.Leer(id);
             MedioDePagoViewModel medioDePagoAEditar = new MedioDePagoViewModel() 
            {
                Id = mediosDePago.Id,
                Nombre = mediosDePago.Nombre,
                Descripcion = mediosDePago.Descripcion,
                
                
                
            };


            return View("EditarMediodePago", medioDePagoAEditar);
        }

        [HttpPost]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> ActualizarMedioDePago(MedioDePagoViewModel model)
        {
            MediosDePago medioDePagoAEditar = await _MedioDePagoService.Leer(model.Id);
            if (medioDePagoAEditar == null)
            {
                TempData["ErrorMessage"] = "Medio de pago no encontrado";
                return RedirectToAction("EditarMedioDePago", new { id = model.Id });
            }

            MediosDePago medioDePago = new MediosDePago()
            {
                Id = model.Id,
                Nombre = model.Nombre,
                Descripcion = model.Descripcion,
                
                
             
            };

            bool response = await _MedioDePagoService.Actualizar(medioDePago);

            if (response)
            {
                return RedirectToAction("Index", "MediosDePagos");
            }
            else
            {
                TempData["ErrorMessage"] = "Error al actualizar Cliente";
                return RedirectToAction("EditarMedioDePago", new { id = model.Id });
            }
        }
    }
}


