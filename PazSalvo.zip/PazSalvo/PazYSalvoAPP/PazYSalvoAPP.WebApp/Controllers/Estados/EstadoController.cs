﻿using Microsoft.AspNetCore.Mvc;
using PazYSalvoAPP.Business.Services;
using PazYSalvoAPP.Models;
using PazYSalvoAPP.WebApp.Models.ViewModels;

namespace PazYSalvoAPP.WebApp.Controllers.Estados
{
    public class EstadoController : Controller
    {
        private readonly IEstadoService _estadoService;
        public EstadoController(IEstadoService estadoService)
        {
            _estadoService = estadoService;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> ListarEstados()
        {
            IQueryable<Estado>? consultaDeEstados = await _estadoService.LeerTodos();

            List<Estado> listadoDeEstados = consultaDeEstados.Select(e => new Estado
            {
                Id = e.Id,
                Nombre = e.Nombre,
                Descripcion = e.Descripcion,

            }).ToList();

            return PartialView("_ListadoDeEstado",
                              listadoDeEstados);

        }

        [HttpPost]
        public async Task<IActionResult> AgregarEstado([FromBody] EstadoViewModel model)
        {
            Estado estado = new Estado()
            {
                Id = model.Id,
                Nombre = model.Nombre,
                Descripcion = model.Descripcion,


            };

            bool response = await _estadoService.Insertar(estado);

            if (response)
            {

                return Json(new { success = true, message = "Estado agregado con exito!" });
            }
            else
            {
                return Json(new { success = false, message = "Error! al agregar el Estado" });
            }

        }

        public async Task<IActionResult> EditarEstado(int id)
        {
            var estado = await _estadoService.Leer(id);
           EstadoViewModel estadoAEditar = new EstadoViewModel()
            {
                Id = estado.Id,
                Nombre = estado.Nombre,
                Descripcion = estado.Descripcion,



            };


            return View("EditarMediodePago", estadoAEditar);
        }

        [HttpPost]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> ActualizarMedioDePago(EstadoViewModel model)
        {
            Estado estadoAEditar = await _estadoService.Leer(model.Id);
            if (estadoAEditar == null)
            {
                TempData["ErrorMessage"] = "Medio de pago no encontrado";
                return RedirectToAction("EditarMedioDePago", new { id = model.Id });
            }

            Estado estado = new Estado()
            {
                Id = model.Id,
                Nombre = model.Nombre == null ? estadoAEditar.Nombre : model.Nombre,
                Descripcion = model.Descripcion == null ? estadoAEditar.Descripcion : model.Descripcion,



            };

            bool response = await _estadoService.Actualizar(estado);

            if (response)
            {
                return RedirectToAction("Index", "Estado");
            }
            else
            {
                TempData["ErrorMessage"] = "Error al actualizar el Estado";
                return RedirectToAction("EditarEstado", new { id = model.Id });
            }
        }
    }
}
