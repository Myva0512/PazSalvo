# PazYSalvoApp
PazYSalvoApp es una aplicación de gestión desarrollada en C# utilizando Visual Studio. Esta aplicación permite a los usuarios llevar un registro de las facturas, del estado de sus facturas, los servicios, los clientes, entre otras funcionalidades.

# Características
**Administrador de facturas:** Este administrador nos permite visualizar y gestionar todo lo referente a las Facturas del negocio como cliente, saldo, servicio, medio de pago,etc.
**Administrador de estados:** Este administrador nos permite visualizar y gestionar todo lo referente a estados de las facturas del negocio.
**Administrador de servicios:** Este administrador nos permite visualizar y gestionar todo lo referente a los servicios del negocio.
**Administrador de Clientes:** Este administrador nos permite visualizar y gestionar todo lo referente a los clientes del negocio.
**Medios de Pago:** En este apartado podremos visualizar los diferentes medios de pago permitidos por nuestra app.
**Administrador de pagos:** Este administrador nos permite ver y actualizar los diferentes pagos realizados por el cliente.
**Administrador de Roles:** En este apartado puedes ver cada uno de los roles disponibles.
**Administrador de persona:** Este administrador nos permite visualizar y gestionar todo lo referente a las persona del negocio.
**Administrador de usuarios:** Este administrador nos permite visualizar y gestionar todo lo referente a los usuarios del negocio.
**Interfaz intuitiva:** La interfaz de usuario ha sido diseñada para ser intuitiva y fácil de usar, facilitando la navegación y el uso de la aplicación.

# Requisitos del sistema
Visual Studio 2019 o superior
.NET Framework 4.7.2 o superior
SQL Server para la gestión de la base de datos.

# Instalación
1. Clona o descarga el repositorio de GitHub.
2. Abre el proyecto en Visual Studio.
3. Compila la solución.
4. Ejecuta la aplicación desde Visual Studio o desde el archivo ejecutable generado.

# Uso
Al abrir la aplicación, serás recibido por la pantalla principal donde podrás ver todos los apartados de la aplicacion.
Utiliza el menú de navegación para acceder a las diferentes funciones de la aplicación, como agregar una nueva factura, ver los estados, gestionar los servicios, etc.
Sigue las instrucciones en pantalla para completar las diversas tareas disponibles.

# Contribuciones
Las contribuciones son bienvenidas. Si deseas contribuir a este proyecto, sigue estos pasos:

1. Realiza un fork del repositorio.
2. Crea una nueva rama (git checkout -b feature/feature-name).
3. Realiza tus cambios y haz commits (git commit -am 'Add new feature').
4. Sube tus cambios al repositorio (git push origin feature/feature-name).
5. Abre un pull request.

# Autores
Julian Obregon - JulianOG18
Yurany Velasquez - Myva0512

# Licencia
Este proyecto está licenciado bajo la Licencia MIT. Consulta el archivo LICENSE para más detalles.